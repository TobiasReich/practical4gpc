#ifndef TREESMALL_H
#define TREESMALL_H

#include <GameObject.h>


class TreeSmall : public GameObject
{
    public:

        TreeSmall();
        virtual ~TreeSmall();


    protected:
    private:
};

#endif // TREESMALL_H
