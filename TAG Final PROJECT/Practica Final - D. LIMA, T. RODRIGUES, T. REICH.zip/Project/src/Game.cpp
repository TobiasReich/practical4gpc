#include "Game.h"

/**
This class is the base for the whole game. It contains the game logic but also the game elements.
It is also a container for the World and Player class

**/


Game::Game() {
    //ctor
}

Game::~Game() {
    //dtor
}

// Initializes game values and fields
void Game::initGame(void){
}

// starts the game (loop etc.)
void Game::startGame(void){
}

