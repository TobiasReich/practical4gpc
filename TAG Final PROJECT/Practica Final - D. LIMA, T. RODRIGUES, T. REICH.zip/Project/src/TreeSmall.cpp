#include "TreeSmall.h"
#include "TextureManager.h"

TreeSmall::TreeSmall()
{
    //ctor
}

TreeSmall::~TreeSmall()
{
    //dtor
}

